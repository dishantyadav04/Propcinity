'use client';

import { Search, Bell, X, LogOut } from "lucide-react";
import { usePathname, useRouter } from "next/navigation";
import Link from "next/link";
import { useState } from "react";
import { useGuestMode } from "@/hooks/useGuestMode";
import { signOut } from "@/lib/supabase-auth";

export default function TopHeader() {
  const pathname = usePathname();
  const router = useRouter();
  const { isGuest: isGuestRaw, isChecking } = useGuestMode();
  const isGuest = !isChecking && isGuestRaw;
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  if (
    pathname.startsWith('/admin') ||
    pathname === '/' ||
    pathname === '/onboarding'
  ) return null;

  const handleSignOut = async () => {
    await signOut();
    router.push('/');
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      router.push(`/explore?q=${encodeURIComponent(searchQuery.trim())}`);
      setSearchOpen(false);
      setSearchQuery('');
    }
  };

  const navItems = isGuest
    ? [
        { label: 'Explore', href: '/explore' },
        { label: 'AI Chat', href: '/ai-chat' },
        { label: 'Compare', href: '/compare' },
      ]
    : [
        { label: 'Dashboard', href: '/dashboard' },
        { label: 'Explore', href: '/explore' },
        { label: 'AI Chat', href: '/ai-chat' },
        { label: 'Compare', href: '/compare' },
      ];

  return (
    <header className="sticky top-0 z-40 bg-[var(--surface)]/95 backdrop-blur-xl border-b border-[var(--border)]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">

        {/* Logo */}
        <Link href={isGuest ? '/onboarding' : '/dashboard'} className="flex items-center flex-shrink-0">
          <span className="text-xl font-black text-[var(--text-primary)] tracking-tight"
            style={{ fontFamily: 'var(--font-display)' }}>
            Prop<span className="text-[var(--primary)]">cinity</span>
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-1">
          {navItems.map(item => (
            <Link key={item.href} href={item.href}
              className={`px-4 py-2 rounded-[var(--radius-xs)] text-sm font-semibold transition-colors ${
                pathname === item.href
                  ? 'bg-[var(--primary-light)] text-[var(--primary)]'
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--surface-raised)]'
              }`}>
              {item.label}
            </Link>
          ))}
        </nav>

        {/* Sign Out for authenticated users */}
        {!isGuest && (
          <button
            onClick={handleSignOut}
            className="hidden md:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold
              text-[var(--text-muted)] hover:text-[var(--danger)] transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" /> Sign out
          </button>
        )}

        {/* Search + Actions */}
        <div className="flex items-center gap-2">
          {searchOpen ? (
            <form onSubmit={handleSearch} className="flex items-center gap-2">
              <input
                autoFocus
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search projects..."
                className="w-48 sm:w-64 px-3 py-1.5 text-sm bg-[var(--surface-raised)] border border-[var(--border-strong)] rounded-[var(--radius-xs)] text-[var(--text-primary)] placeholder:text-[var(--text-muted)] focus:outline-none focus:border-[var(--primary)]"
              />
              <button type="button" onClick={() => setSearchOpen(false)}
                className="p-1.5 text-[var(--text-muted)] hover:text-[var(--text-primary)]">
                <X className="w-4 h-4" />
              </button>
            </form>
          ) : (
            <button onClick={() => setSearchOpen(true)}
              className="p-2 text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--surface-raised)] rounded-[var(--radius-xs)] transition-colors">
              <Search className="w-5 h-5" />
            </button>
          )}
          {isGuest ? (
            <Link
              href="/onboarding"
              className="px-4 py-2 bg-[var(--primary)] text-white text-sm font-bold rounded-[var(--radius-xs)] hover:opacity-90 transition-opacity shadow-[var(--shadow-primary)]"
            >
              Sign Up / Login
            </Link>
          ) : (
            <Link
              href="/profile"
              className="w-9 h-9 rounded-full bg-[var(--primary)] flex items-center justify-center hover:opacity-90 transition-opacity shadow-sm"
              aria-label="Profile"
            >
              <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5 text-white" stroke="currentColor" strokeWidth={2}>
                <circle cx="12" cy="7" r="3.5" />
                <path d="M4 20c0-4.418 3.582-8 8-8s8 3.582 8 8" strokeLinecap="round" />
              </svg>
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}
